"""organize.preimport.plan - the read-only half of the preimport pass:
scan <input> and <crate>/albums and decide where every album-group file
should end up (merge into an existing crate album, stage a new album
folder, or pass through as a singleton). apply.py's stage() calls
index_existing_albums() and build_plan() below, then performs the
actual moves/tag-writes.

three outcomes per group (= album tag shared):
  merge   - existing crate folder matched: move INTO it, tag with its albumartist
  stage   - no match, >=2 tracks: new folder under <input>/albums/, tag canonical aa
  pass    - no match, lone track: leave where it is for the beets singles pass
files with no album tag are singletons - left untouched for the singles pass.
"""

import os
from dataclasses import dataclass
from typing import List, Tuple

from lib.tags import EXTENSIONS, canonical_album, canonical_albumartist, dominant_album, find_duplicates, read_tags, sanitize
from lib.text import normalize_album
from lib.naming import _track_label, album_folder_name
from organize.cleanup import is_unrelated_va_collision


def _first_audio(folder):
    """first audio file under folder (sorted for determinism), or None."""
    for dp, dirs, fns in os.walk(folder):
        dirs[:] = [d for d in dirs if d != '__pycache__']
        for fn in sorted(fns):
            if fn.lower().endswith(EXTENSIONS):
                return os.path.join(dp, fn)
    return None


def index_existing_albums(crate):
    """map (albumartist_raw, album_raw) -> (folder_path, albumartist_raw, album_raw)
    for every album folder under <crate>/albums, read off one file's tags.

    Bug 3b: store raw albumstring and albumartiststring instead of normalized versions
    so preimport merges can compute canonical_album() over incoming ∪ existing.

    an album name collision across multiple folders marks the key None
    (ambiguous) so stage() refuses to merge against it - staging a new folder is
    always safer than risking a wrong merge of two different real albums that
    happen to share a normalized name."""
    root = os.path.join(crate, 'albums')
    if not os.path.isdir(root):
        return {}
    idx = {}
    for d in sorted(os.listdir(root)):
        full = os.path.join(root, d)
        if not os.path.isdir(full):
            continue
        rep = _first_audio(full)
        if not rep:
            continue
        tags = read_tags(rep)
        if tags is None:
            continue
        albumartist, album = tags['albumartist'], tags['album']
        if not album:
            continue
        # Bug 3b: store raw strings instead of normalized
        # But use normalized key for collision detection
        norm_key = (normalize_album(albumartist or ''), normalize_album(album or ''))
        if norm_key in idx:
            idx[norm_key] = None  # ambiguous: >=2 existing folders match -> never merge
        else:
            idx[norm_key] = (full, albumartist or '', album or '')
    return idx


def _read_crate_folder(folder):
    """read tags for every audio file in <folder>, used by Bug 14 duplicate
    detection to compare incoming members against existing crate files via
    find_duplicates() (artist+title+duration within ~2s) instead of a
    normalize_key(title) set, which false-positives on non-Latin titles
    that key to ''."""
    files = []
    for dp, dirs, fns in os.walk(folder):
        dirs[:] = [d for d in dirs if d != '__pycache__']
        for fn in sorted(fns):
            if not fn.lower().endswith(EXTENSIONS):
                continue
            t = read_tags(os.path.join(dp, fn))
            if t:
                files.append(t)
    return files


def _member_name(i, m, folder_path, seen):
    """NN - Artist - Title.ext, disambiguated on collision within the folder.
    matches beets' default path template so the staged name is what beets keeps."""
    ext = os.path.splitext(m['path'])[1]
    name = f"{_track_label(i, m)} - {sanitize(m['artist'])} - {sanitize(m['title'])}{ext}"
    taken = seen.setdefault(folder_path, set())
    base, sfx = os.path.splitext(name)
    c = 2
    while name.lower() in taken:
        name = f"{base} ({c}){sfx}"
        c += 1
    taken.add(name.lower())
    return name


@dataclass
class Plan:
    """Dataclass for build_plan return value."""
    report: dict
    staged_moves: List[Tuple[str, str, str]]  # (src, dst, aa_for_tag)
    merged_moves: List[Tuple[str, str, str]]  # (src, dst, aa_for_tag)
    dup_moves: List[Tuple[str]]               # (src,) - tracks the target album already owns
    tag_writes: List[Tuple[str, str]]         # (src, aa_for_tag)
    album_tag_writes: List[Tuple[str, str]]   # (src, album)


def build_plan(groups, unorganized, crate, idx):
    """decide a destination + albumartist + album tag for every album-group file.
    returns Plan dataclass.

    three outcomes per group (= album tag shared):
      merge   - existing crate folder matched: move INTO it, tag with its albumartist
      stage   - no match, >=2 tracks: new folder under <input>/albums/, tag canonical aa
      pass    - no match, lone track: leave where it is for the beets singles pass
    files with no album tag are singletons - left untouched for the singles pass."""
    staging_root = os.path.join(unorganized, 'albums')
    singles_dir = os.path.join(crate, 'singles')

    staged_moves = []     # (src, dst, aa_for_tag)
    merged_moves = []     # (src, dst, aa_for_tag)
    dup_moves = []        # (src,) - tracks the target album already owns; -> duplicates/
    tag_writes = []       # (src, aa_for_tag)
    album_tag_writes = []   # (src, album)
    singleton_moves = []  # (src, dst) - singleton moves
    noop = 0              # number of files already in place
    seen = {}             # folder -> set of lowercased names (collision guard within folder)
    seen_staged = set()   # set of lowercased staged folder names (collision guard)
    seen_singletons = set()  # Track lowercase destination paths for singleton collision detection
    report = {
        'scanned': sum(len(v) for v in groups.values()),
        'staged_folders': [],
        'merged_folders': [],
        'merged_tracks': 0,
        'split_groups': [],
        'duplicates': [],
        'tag_writes': 0,
        'singletons': 0,
        'ambiguous': [],
    }

    for (kind, _), members in groups.items():
        if kind == 'single':
            # no album tag at all -> true singleton, leave for the singles pass
            report['singletons'] += len(members)
            continue

        aa = canonical_albumartist(members)
        album = dominant_album(members)

        if _handle_va_collision_if_needed(members, album, report):
            continue

        # Bug 3b: use raw album string for lookup, but compute canonical_album() over incoming ∪ existing
        album_raw = members[0]['album'] or ''
        aa_raw = members[0]['albumartist'] or members[0]['artist'] or ''
        entry, existing_folder_match = _find_existing_folder_match(idx, album_raw, aa_raw)

        # Determine if we can merge (have an existing match)
        can_merge = entry is not None or existing_folder_match is not None

        # >=2 existing crate folders normalize to this (aa, album) -> idx flagged it
        # None -> can't safely merge; stage (if multi-track) or leave as singleton,
        # but record it so the user sees why a would-be merge was declined.
        norm_key = (normalize_album(aa_raw or ''), normalize_album(album_raw or ''))
        ambiguous = bool(idx) and norm_key in idx and idx[norm_key] is None

        # Record ambiguous keys for the report
        if ambiguous:
            report['ambiguous'].append((aa_raw or '', album_raw or ''))

        if can_merge:
            # merge into an existing crate album folder
            _handle_merge_group(
                members, entry, existing_folder_match, aa, album, crate, idx,
                staged_moves, merged_moves, dup_moves, tag_writes, album_tag_writes,
                report, seen
            )
        elif len(members) >= 2:
            # Bug 5: remove Various Artists override - do not override Various Artists based on raw artist tags
            # no existing match, multi-track -> stage a new album folder for pass 1
            _handle_stage_group(members, aa, album, staging_root, idx,
                              staged_moves, merged_moves, dup_moves, tag_writes, album_tag_writes, report, seen, seen_staged)
        else:
            # lone track of an album we don't have -> behaves like a singleton
            # Apply same collision/duplicate handling as used for album folders
            report['singletons'] += 1
            if not _handle_singleton_album_track(members, singles_dir, singleton_moves, seen_singletons):
                # File needs to be moved (handled inside helper function)
                pass
            else:
                # File was already in place
                noop += 1

    return Plan(report, staged_moves, merged_moves, dup_moves, tag_writes, album_tag_writes)


def _handle_singleton_group(members, report):
    """Handle a group with no album tag (true singletons)."""
    report['singletons'] += len(members)


def _handle_va_collision_if_needed(members, album, report):
    """Check if group is an unrelated VA collision and handle it if so.
    Returns True if handled (should continue), False otherwise."""
    if is_unrelated_va_collision(members):
        report['singletons'] += len(members)
        report['split_groups'].append((album, len(members)))
        return True
    return False


def _find_existing_folder_match(idx, album_raw, aa_raw):
    """Find existing folder match for the given album/albumartist.
    Returns tuple (entry, existing_folder_match) where:
    - entry is the direct idx lookup result (may be None or ambiguous)
    - existing_folder_match is the case-insensitive match result (may be None)
    """
    entry = idx.get((normalize_album(aa_raw or ''), normalize_album(album_raw or ''))) if idx else None

    # Keep-existing-folder rule: check for case-insensitive match in existing crate albums
    existing_folder_match = None
    if entry is None and idx:
        for (norm_artist, norm_album), value in idx.items():
            if value is not None:  # Not ambiguous
                (full_path, raw_artist, raw_album) = value
                if raw_artist.lower() == aa_raw.lower() and raw_album.lower() == album_raw.lower():
                    existing_folder_match = (full_path, raw_artist, raw_album)
                    break

    return entry, existing_folder_match


def _existing_dup_paths(dup_groups, existing_paths):
    """Paths of incoming tracks in duplicate groups that also contain a file
    the crate already owns - those incoming tracks duplicate existing crate
    files."""
    dup_paths = set()
    for dg in dup_groups:
        if any(f['path'] in existing_paths for f in dg):
            for f in dg:
                if f['path'] not in existing_paths:
                    dup_paths.add(f['path'])
    return dup_paths


def _all_dup_paths(dup_groups):
    """Every path mentioned in the duplicate groups."""
    return {f['path'] for dg in dup_groups for f in dg}


def _handle_merge_group(members, entry, existing_folder_match, aa, album, crate, idx,
                       staged_moves, merged_moves, dup_moves, tag_writes, album_tag_writes, report, seen):
    """Handle merging a group into an existing crate album folder."""
    if entry is not None:
        folder_path, existing_aa, existing_album = entry
    else:
        folder_path, existing_aa, existing_album = existing_folder_match
    aa_for_tag = existing_aa or aa
    # Bug 3b: compute canonical_album() over incoming ∪ existing
    all_albums = [m['album'] or '' for m in members] + [existing_album]
    canonical_album_val = canonical_album([{'album': alb} for alb in all_albums if alb])
    # Bug 14: compare incoming members against existing folder files using
    # find_duplicates() (artist+title+duration within ~2s) instead of a
    # normalize_key(title) set, which false-positives on non-Latin titles
    # that key to ''.
    existing_files = _read_crate_folder(folder_path)
    existing_paths = {ef['path'] for ef in existing_files}
    dup_groups = find_duplicates(existing_files + list(members))
    existing_dup_paths = _existing_dup_paths(dup_groups, existing_paths)
    # Bug 8: hoist find_duplicates(members) out of the per-member loop - O(n²) called n times = O(n³)
    incoming_dup_paths = _all_dup_paths(find_duplicates(list(members)))
    merged_here = 0
    for i, m in enumerate(members):
        _process_member_for_merge(
            i, m, existing_dup_paths, incoming_dup_paths, folder_path, seen,
            aa_for_tag, canonical_album_val, album,
            merged_moves, dup_moves, tag_writes, album_tag_writes, report
        )
        merged_here += 1
    # album tag writes: enforce the dominant album string so all files in group agree
    for m in members:
        if (m['album'] or '') != album:
            album_tag_writes.append((m['path'], album))
    if merged_here:
        report['merged_folders'].append(folder_path)
    report['merged_tracks'] += merged_here


def _process_member_for_merge(i, m, existing_dup_paths, incoming_dup_paths, folder_path, seen,
                             aa_for_tag, canonical_album_val, album,
                             merged_moves, dup_moves, tag_writes, album_tag_writes, report):
    """Process a single member for merge handling.
    Checks for duplicates and adds appropriate moves/tags to the provided lists.
    incoming_dup_paths is precomputed from find_duplicates(members) to avoid
    O(n²) work inside the per-member loop (would be O(n³) overall)."""
    # Bug 14: duplicate detection uses find_duplicates() (artist+title+duration
    # within ~2s) instead of normalize_key(title), which false-positives on
    # non-Latin titles that key to ''.
    duplicate_paths = incoming_dup_paths

    # skip tracks the album already owns (duplicate of an existing crate file)
    # or duplicates within the incoming group - quarantine rather than create
    # a cross-format dup beside the original.
    if m['path'] in existing_dup_paths or m['path'] in duplicate_paths:
        dup_moves.append((m['path'],))
        report['duplicates'].append(
            (m['path'], folder_path, m['title']))
        return
    dst = os.path.join(folder_path, _member_name(i, m, folder_path, seen))
    if os.path.normpath(dst) != os.path.normpath(m['path']):
        merged_moves.append((m['path'], dst, aa_for_tag))
    if (m['albumartist'] or '') != aa_for_tag:
        tag_writes.append((m['path'], aa_for_tag))
    if (m['album'] or '') != canonical_album_val:
        album_tag_writes.append((m['path'], canonical_album_val))


def _handle_stage_group(members, aa, album, staging_root, idx,
                       staged_moves, merged_moves, dup_moves, tag_writes, album_tag_writes, report, seen, seen_staged):
    """Handle staging a new album folder for a group with no existing match."""
    # Bug 5: remove Various Artists override - do not override Various Artists based on raw artist tags
    # no existing match, multi-track -> stage a new album folder for pass 1
    folder_name = album_folder_name(aa, album)
    folder_path = os.path.join(staging_root, folder_name)

    # Check for collisions and disambiguate if needed
    name = folder_name
    c = 2
    while os.path.normpath(os.path.join(staging_root, name)).lower() in seen_staged:
        name = f"{os.path.splitext(folder_name)[0]} ({c}){os.path.splitext(folder_name)[1]}"
        c += 1
    seen_staged.add(os.path.normpath(os.path.join(staging_root, name)).lower())

    # Bug 8: hoist find_duplicates(members) out of the per-member loop - O(n²) called n times = O(n³)
    incoming_dup_groups = find_duplicates(members)
    duplicate_paths = set()
    for dg in incoming_dup_groups:
        for dup_file in dg:
            duplicate_paths.add(dup_file['path'])

    staged_here = 0
    for i, m in enumerate(members):
        # Bug 14: duplicate detection uses find_duplicates() (artist+title+duration
        # within ~2s) instead of normalize_key(title), which false-positives on
        # non-Latin titles that key to ''.

        # skip tracks that are duplicates within the incoming group -
        # quarantine rather than create a cross-format dup beside the original.
        if m['path'] in duplicate_paths:
            dup_moves.append((m['path'],))
            report['duplicates'].append(
                (m['path'], folder_path, m['title']))
            continue
        dst = os.path.join(folder_path, _member_name(i, m, folder_path, seen))
        if os.path.normpath(dst) != os.path.normpath(m['path']):
            staged_moves.append((m['path'], dst, aa))
        if (m['albumartist'] or '') != aa:
            tag_writes.append((m['path'], aa))
        if (m['album'] or '') != album:
            album_tag_writes.append((m['path'], album))
        staged_here += 1
    if staged_here:
        report['staged_folders'].append(folder_path)


def _handle_singleton_album_track(members, singles_dir, singleton_moves, seen_singletons):
    """Handle a lone track of an album we don't have (behaves like a singleton).
    Adds move to singleton_moves if needed.
    Returns True if the file was already in place (no move needed), False otherwise."""
    # Apply same collision/duplicate handling as used for album folders
    f = members[0]
    ext = os.path.splitext(f['path'])[1]
    base_name = f"{sanitize(f['artist'])} - {sanitize(f['title'])}{ext}"

    # Check for collisions and disambiguate if needed
    name = base_name
    c = 2
    while os.path.normpath(os.path.join(singles_dir, name)).lower() in seen_singletons:
        name = f"{os.path.splitext(base_name)[0]} ({c}){os.path.splitext(base_name)[1]}"
        c += 1
    seen_singletons.add(os.path.normpath(os.path.join(singles_dir, name)).lower())

    dst = os.path.join(singles_dir, name)
    if os.path.normpath(dst) != os.path.normpath(f['path']):
        singleton_moves.append((f['path'], dst))
        return False  # Move needed
    else:
        return True   # Already in place
