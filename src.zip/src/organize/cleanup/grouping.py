"""organize.cleanup.grouping - the forward-looking regroup pass: decide
where every file in <crate>/albums + <crate>/singles belongs.

  - group every audio file by its album tag (group_files)
  - >=2 files sharing an album -> one album folder, named
    <albumartist> - <album>; canonical albumartist per group is the
    dominant artist string across the group's files (lib.tags.
    canonical_albumartist)
  - exactly 1 file per album, or no album tag -> singleton
  - a group whose members split into disconnected artist components
    (raw `artist` tag only - never albumartist, which this module writes)
    is a same-titled-singles collision unless the compilation guard or
    ambiguity rule says otherwise (resolve_group); components of size 1
    become singletons, size >= 2 stay albums. Fixes e.g. "Anysia Kym - Automatic" and "Spencer. -
    Automatic" colliding into one "Various Artists - Automatic" folder
    just because they share a title. See BUGFIX_PLAN.md's Bug 2.

this module only decides where things go (build_plan()'s returned move
lists); apply.py's run_cleanup() performs the moves/tag-writes and owns
the printed report. This module's forward-looking grouping logic prevents
new wrong merges (Bug 2b); folders that were already wrongly merged before
the grouping-key fix are now handled by the regular cleanup pass's improved
grouping rather than a separate repair mode. See BUGFIX_PLAN.md Phase 4
for the retirement of --resplit and the carryover of _artist_components()
into split_group().
"""

import collections
import os
import unicodedata
from dataclasses import dataclass, field
from typing import List, Tuple

from lib.tags import (
    artist_tokens,
    canonical_albumartist,
    dominant_album,
    find_duplicates,
    sanitize,
    same_path,
    split_group,
    unique_name,
)
from lib.naming import _track_label, album_folder_name, singleton_filename
from lib.text import normalize_key, group_album_key


def _artist_tokens(f):
    """normalized artist-name tokens for one file - RAW `artist` tag only.
    (kept as a name for callers/tests; see lib.tags.artist_tokens for why
    albumartist is excluded: this module writes it, so it's poisoned.)"""
    return artist_tokens(f)


def _is_explicit_va_member(f):
    """True if this file's own albumartist tag says Various Artists/VA."""
    return normalize_key(f.get('albumartist') or '') in ('variousartists', 'va')


_is_explicit_va = _is_explicit_va_member


def shares_artist_token(members):
    """True if at least two members share an artist token (raw artist only)."""
    if len(members) < 2:
        return False
    token_sets = [_artist_tokens(m) for m in members]
    for i in range(len(token_sets)):
        for j in range(i + 1, len(token_sets)):
            if token_sets[i] & token_sets[j]:
                return True
    return False


def is_unrelated_va_collision(members):
    """True when exactly two files share an album key but have completely
    disjoint artists (raw artist tag), and neither carries an explicit
    Various Artists/VA albumartist. Still used by preimport/plan.py; cleanup
    uses resolve_group() below, which handles any group size."""
    if len(members) != 2:
        return False
    if any(_is_explicit_va_member(m) for m in members):
        return False
    return not shares_artist_token(members)


def _group_album_key_of(members):
    keys = [group_album_key(m['album']) for m in members if m['album']]
    if not keys:
        return ''
    return collections.Counter(keys).most_common(1)[0][0]


def _is_self_titled(m, album_key):
    """a single-release row: title == album (edition stripped, unicode-aware)."""
    return bool(album_key) and group_album_key(m['title'] or '') == album_key


def _self_titled_fraction(members):
    if not members:
        return 0.0
    key = _group_album_key_of(members)
    return sum(1 for m in members if _is_self_titled(m, key)) / len(members)


def _self_titled_singles(members):
    """indices of self-titled-single signals: title == album key AND artist
    tokens disjoint from every other member."""
    key = _group_album_key_of(members)
    out = set()
    for i, m in enumerate(members):
        if not _is_self_titled(m, key):
            continue
        others = set()
        for j, o in enumerate(members):
            if i != j:
                others |= _artist_tokens(o)
        if not (_artist_tokens(m) & others):
            out.add(i)
    return out


def _is_compilation_guard(members):
    """never split: a real compilation = >=4 members, >=50% explicit
    Various Artists/VA albumartist, AND titles mostly != album (a pile of
    same-titled singles has title == album on most rows, even when an
    earlier cleanup stamped them all 'Various Artists' - so VA alone is not
    enough to protect a group)."""
    n = len(members)
    if n < 4:
        return False
    va = sum(1 for m in members if _is_explicit_va_member(m))
    return va >= n * 0.5 and _self_titled_fraction(members) < 0.5


def _is_ambiguous_group(members, components):
    """>=4 members, no explicit-VA majority, titles mostly != album, and no
    component holds >=50% of the group: could be an untagged compilation or a
    pile-up. Left merged and reported for manual review."""
    n = len(members)
    if n < 4:
        return False
    va = sum(1 for m in members if _is_explicit_va_member(m))
    if va >= n * 0.5 or _self_titled_fraction(members) >= 0.5:
        return False
    return max(len(c) for c in components) < n * 0.5


def resolve_group(members):
    """decide how one album-keyed group should be treated.
    returns (components, status); status is one of
      'whole'     - one connected component (or <2 members): normal album
      'guarded'   - real compilation, never split
      'ambiguous' - murky >=4 group, kept merged + reported
      'split'     - components should be handled separately
                  (size>=2 -> album, size 1 -> singleton)."""
    if len(members) < 2:
        return [members], 'whole'
    comps = split_group(members)
    if len(comps) == 1:
        return [members], 'whole'
    if _is_compilation_guard(members):
        return [members], 'guarded'
    if _is_ambiguous_group(members, comps):
        return [members], 'ambiguous'
    return comps, 'split'


@dataclass
class Plan:
    """Dataclass for build_plan return value."""
    album_moves: List[Tuple[str, str, str]]  # (src, dst, new_albumartist)
    singleton_moves: List[Tuple[str, str]]   # (src, dst)
    noop_count: int                          # number of files already in place
    tag_writes: List[Tuple[str, str]]        # (src, new_albumartist)
    album_tag_writes: List[Tuple[str, str]]  # (src, new_album)
    va_groups: List[Tuple[str, int, List[str]]]  # (album, track_count, src_skewed_folders)
    split_groups: List[Tuple[str, int]]      # (album, track_count) - false-VA collisions split apart
    ambiguous_groups: List[Tuple[str, int, List[str]]] = field(default_factory=list)  # (album, n, artists)
    dup_moves: List[Tuple[str, str]] = field(default_factory=list)  # (src, dst) - true duplicates -> duplicates/


def group_files(files):
    """group by normalised album identity (empty album -> its own
    single-element bucket so it stays a singleton). Uses
    lib.text.group_album_key() rather than plain normalize_album() so a
    track tagged "Album" and one tagged "Album (Deluxe)"/"Album (2009
    Remaster)" land in the same group instead of forking into two -
    canonical_albumartist()/dominant_album() then pick the folder
    name/tag from whichever raw string is more common across the merged
    group, same majority-vote behavior as any other tag disagreement (no
    new canonical string is invented here - see TODO.md's separate
    apply-time-cleanup item for that). returns {group_key: [file, ...]}
    preserving order."""
    groups = collections.OrderedDict()
    for i, f in enumerate(files):
        if f['album']:
            key = ('album', group_album_key(f['album']))
        else:
            key = ('single', i)  # unique per file - never merge missing-album files
        groups.setdefault(key, []).append(f)
    return groups


def build_plan(groups, crate):
    """decide a target path + tag fix for every file. returns Plan."""

    albums_dir = os.path.join(crate, 'albums')
    singles_dir = os.path.join(crate, 'singles')

    album_moves, singleton_moves = [], []
    dup_moves = []
    tag_writes, album_tag_writes = [], []
    va_groups, split_groups, ambiguous_groups = [], [], []
    noop_count = 0
    seen_singletons = set()

    for (kind, _), members in groups.items():
        # no album tag / lone track / empty key (Bug 4: never merge on emptiness)
        if kind == 'single' or len(members) == 1 or not (
                members[0]['album'] and group_album_key(members[0]['album'])):
            noop_count += _plan_singletons(members, albums_dir, singles_dir,
                                           seen_singletons, singleton_moves)
            continue

        status, album, artists_list, components = _handle_group_status(
            members, resolve_group, dominant_album)
        if status == 'split':
            split_groups.append((album, len(members), artists_list))
        elif status == 'ambiguous':
            ambiguous_groups.append((album, len(members), artists_list))

        for component in components:
            if len(component) == 1:
                noop_ref = [0]
                _add_singleton(component[0], albums_dir, singles_dir,
                               seen_singletons, singleton_moves, noop_ref)
                noop_count += noop_ref[0]
            else:
                _add_album(component, albums_dir, singles_dir, seen_singletons,
                           album_moves, singleton_moves, tag_writes, album_tag_writes,
                           va_groups, heal_va=(status == 'split'), dup_moves=dup_moves)

    # De-duplicate quarantine destinations: two same-cased basenames from
    # different components must not collide in duplicates/ (Fix 6).
    dup_moves = _deduplicate_dup_moves(dup_moves)

    # Planner assertions: no two moves share a destination, and no source has
    # conflicting tag writes.
    _assert_unique_destinations(album_moves, singleton_moves, dup_moves)
    _assert_no_conflicting_tag_writes(tag_writes, album_tag_writes)

    return Plan(album_moves, singleton_moves, noop_count, tag_writes, album_tag_writes,
                va_groups, split_groups, ambiguous_groups, dup_moves)


def _plan_singletons(members, albums_dir, singles_dir, seen_singletons,
                     singleton_moves):
    """Add singleton moves for every member; returns how many are already in
    place (noop)."""
    noop_ref = [0]
    for f in members:
        _add_singleton(f, albums_dir, singles_dir, seen_singletons,
                       singleton_moves, noop_ref)
    return noop_ref[0]


def _deduplicate_dup_moves(dup_moves):
    """Re-suffix same-cased basenames so quarantine destinations never
    collide in duplicates/ (Fix 6)."""
    seen_dup = set()
    deduped = []
    for src, dst in dup_moves:
        name = os.path.basename(dst)
        if name.lower() in seen_dup:
            name = unique_name(seen_dup, name)
        seen_dup.add(name.lower())
        deduped.append((src, os.path.join(os.path.dirname(dst), name)))
    return deduped


def _assert_unique_destinations(album_moves, singleton_moves, dup_moves):
    """Planner assertion: no two moves share a destination
    (case-insensitively)."""
    all_dsts = ([dst for _, dst, _ in album_moves]
                + [dst for _, dst in singleton_moves]
                + [dst for _, dst in dup_moves])
    all_dsts_lower = [d.lower() for d in all_dsts]
    if len(all_dsts_lower) != len(set(all_dsts_lower)):
        from collections import Counter
        dupes = [d for d, n in Counter(all_dsts_lower).items() if n > 1]
        raise AssertionError(f"build_plan: two moves share destination(s) "
                             f"(case-insensitively): {dupes}")


def _assert_no_conflicting_tag_writes(tag_writes, album_tag_writes):
    """Planner assertion: no two tag writes to the same source with
    different values."""
    for writes in (tag_writes, album_tag_writes):
        write_map = {}
        for src, val in writes:
            if src in write_map and write_map[src] != val:
                raise AssertionError(f"build_plan: conflicting tag writes for {src}")
            write_map[src] = val


def _add_singleton(f, albums_dir, singles_dir, seen_singletons, singleton_moves, noop_ref):
    """Add a singleton file to the plan."""
    ext = os.path.splitext(f['path'])[1]
    base_name = singleton_filename(f['artist'], f['title'], ext)
    name, c = base_name, 2
    while os.path.normpath(os.path.join(singles_dir, name)).lower() in seen_singletons:
        stem, sfx = os.path.splitext(base_name)
        name = f"{stem} ({c}){sfx}"
        c += 1
    seen_singletons.add(os.path.normpath(os.path.join(singles_dir, name)).lower())
    dst = os.path.join(singles_dir, name)
    if not same_path(dst, f['path']):
        singleton_moves.append((f['path'], dst))
    else:
        noop_ref[0] += 1


def _folder_case_key(name):
    """casefold + NFC key for keep-existing-folder comparisons (Bug 6.4)."""
    return unicodedata.normalize('NFC', name.casefold())


def _existing_folder_exact(albums_dir, folder):
    """Keep-existing-folder rule (Bug 6.4): if an existing subdirectory of
    albums_dir matches `folder` case-insensitively (casefold + NFC, exact
    otherwise), return its exact on-disk string. Case alone never triggers a
    rename of an already-correct folder, which kills the
    `Citizen - Youth` <-> `youth` ping-pong. Deliberately not `group_key`-
    based: `group_key` ignores punctuation/spacing, which would block the
    rename of `MndsgnDevonwho - Episodes` -> `Mndsgn, Devonwho - Episodes`."""
    if not os.path.isdir(albums_dir):
        return None
    target = _folder_case_key(folder)
    for d in os.listdir(albums_dir):
        full = os.path.join(albums_dir, d)
        if os.path.isdir(full) and _folder_case_key(d) == target:
            return d
    return None


def _dupe_preference(f):
    """sort key: best copy of a duplicate group first - lossless, then larger."""
    ext = os.path.splitext(f['path'])[1].lower()
    lossless = ext in ('.flac', '.wav', '.alac', '.aiff', '.aif')
    try:
        size = os.path.getsize(f['path'])
    except OSError:
        size = 0
    return (not lossless, -size)


def _add_album(component, albums_dir, singles_dir, seen_singletons,
               album_moves, singleton_moves, tag_writes, album_tag_writes,
               va_groups, heal_va, dup_moves):
    """Add an album component to the plan."""
    # in a group we decided to split, an explicit 'Various Artists'
    # albumartist is self-inflicted (an earlier wrong merge), not a signal -
    # ignore it when picking the folder's albumartist, and the tag write
    # below then repairs it.
    basis = [dict(m, albumartist='') if heal_va and _is_explicit_va_member(m) else m
             for m in component]
    aa = canonical_albumartist(basis)
    album = dominant_album(component)
    folder = album_folder_name(aa, album)
    # Fix 4: keep-existing-folder - reuse an existing folder's exact string
    # when it matches case-insensitively; case alone never renames.
    keep = _existing_folder_exact(albums_dir, folder)
    if keep:
        folder = keep
    src_folders = {os.path.basename(os.path.dirname(m['path'])) for m in component}
    if aa == 'Various Artists':
        va_groups.append((album or folder, len(component), sorted(src_folders)))
    crate = os.path.dirname(albums_dir)
    quarantined = _quarantine_duplicates(component, crate, dup_moves)
    _plan_tag_writes(component, aa, album, quarantined, tag_writes,
                     album_tag_writes)
    _plan_album_moves(component, aa, albums_dir, folder, quarantined,
                      album_moves)


def _quarantine_duplicates(component, crate, dup_moves):
    """Fix 2: true duplicates (same normalized artist + title, duration within
    ~2 s) are quarantined to duplicates/ with the best copy kept, rather
    than being suffixed into (2), (3), ... forever. returns the set of
    quarantined source paths."""
    quarantined = set()
    for dup_group in find_duplicates(component):
        dup_group = sorted(dup_group, key=_dupe_preference)
        for dup in dup_group[1:]:
            quarantined.add(dup['path'])
            dst = os.path.join(crate, 'duplicates', os.path.basename(dup['path']))
            dup_moves.append((dup['path'], dst))
    return quarantined


def _plan_tag_writes(component, aa, album, quarantined, tag_writes,
                     album_tag_writes):
    """Tag-write plan for the non-quarantined members of an album component."""
    for m in component:
        if m['path'] in quarantined:
            continue
        if (m['albumartist'] or '') != aa:
            tag_writes.append((m['path'], aa))
        if (m['album'] or '') != album:
            album_tag_writes.append((m['path'], album))


def _plan_album_moves(component, aa, albums_dir, folder, quarantined,
                      album_moves):
    """Per-file move plan for the non-quarantined members of an album
    component."""
    seen_names = set()
    for idx, m in enumerate(component):
        if m['path'] in quarantined:
            continue
        ext = os.path.splitext(m['path'])[1]
        wanted = f"{_track_label(idx, m)} - {sanitize(m['artist'])} - {sanitize(m['title'])}{ext}"
        cur_base = os.path.basename(m['path'])
        # Incumbent-keeps-name: if current basename already equals the wanted
        # name and it's not taken, keep it (noop). Otherwise get a unique name.
        if cur_base == wanted and wanted.lower() not in seen_names:
            name = wanted
        else:
            name = unique_name(seen_names, wanted)
        seen_names.add(name.lower())
        dst = os.path.join(albums_dir, folder, name)
        if not same_path(dst, m['path']):
            album_moves.append((m['path'], dst, aa))


def _handle_group_status(members, resolve_group, dominant_album):
    """Handle the status resolution for a group and return relevant data.

    Args:
        members: List of group members
        resolve_group: Function to resolve group into components and status
        dominant_album: Function to get dominant album from members

    Returns:
        Tuple of (status, album, artists_list, components)
            status: The group status ('split', 'ambiguous', 'whole', 'guarded')
            album: The dominant album string
            artists_list: List of artist names (for split/ambiguous status)
            components: List of components from resolve_group
    """
    components, status = resolve_group(members)
    album = dominant_album(members)
    artists_list = []
    if status == 'split':
        artists_list = sorted({m['artist'] for m in members})
    elif status == 'ambiguous':
        artists_list = sorted({m['artist'] for m in members})
    return status, album, artists_list, components
