"""download.spotify_export - export spotify playlists + liked songs to csv,
and build a deduplicated manifest of track urls for `spotify_download`.

was spotify_to_csv.py. extract_playlist_id_from_url() now lives in
lib.exclusion (shared with playlists.build and playlists.cli); it is
re-exported here for backward compatibility.

export_playlists() is new (not in the original spotify_to_csv.py): exports
a *list* of specific playlists and merges their tracks into one scoped
manifest, for keeping a subset of playlists in sync independently of the
full library export - see its own docstring.
"""

import os

from lib.exclusion import (
    extract_playlist_id_from_url,
    build_exclude_tokens,
    is_playlist_excluded,
)

from download.spotify.spotify_api import (
    get_user_playlists,
    get_playlist_tracks,
    get_liked_songs,
    merge_and_deduplicate,
    export_to_csv,
    export_manifest_as_txt,
)


def export_specific_playlist(sp, playlist_identifier, export_dir):
    print(f"exporting playlist: {playlist_identifier}")

    playlist_id = extract_playlist_id_from_url(playlist_identifier)

    try:
        playlist = sp.playlist(playlist_id)
        playlist_name = playlist.get('name', 'Unknown Playlist')
        print(f"found playlist: {playlist_name}")

        tracks = get_playlist_tracks(sp, playlist_id, playlist_name)
        print(f"found {len(tracks)} tracks")

        safe_name = "".join(c for c in playlist_name if c.isalnum() or c in (' ', '-', '_')).rstrip()
        safe_name = safe_name.replace(' ', '_')

        # Create spotify subdirectory for service-specific organization
        spotify_dir = os.path.join(export_dir, 'spotify')
        os.makedirs(spotify_dir, exist_ok=True)

        filename = f"playlist_{safe_name}.csv"
        export_to_csv(tracks, filename, spotify_dir)

        txt_filename = f"playlist_{safe_name}_urls.txt"
        txt_filepath = os.path.join(spotify_dir, txt_filename)
        with open(txt_filepath, 'w', encoding='utf-8') as f:
            for track in tracks:
                f.write(track.get('spotify_url', '') + '\n')
        print(f"exported {len(tracks)} spotify urls to {txt_filepath}")

        return tracks

    except Exception as e:
        print(f"error exporting playlist {playlist_identifier}: {e}")
        return []


def export_playlists(sp, playlist_identifiers, export_dir):
    """export a list of specific playlists (urls or ids, mixed is fine) -
    each to its own per-playlist csv/txt via export_specific_playlist(),
    same as always - then merge all their tracks into one deduped
    'playlists_manifest.csv' + urls txt, shaped like spotify_manifest.csv,
    so `download spotify --pre-skip-existing` can be pointed at just this
    subset instead of the full library export.

    this is the mechanism for "update only these playlists": keep a
    --playlists-file list of the ones you actually want synced, re-run
    this export against it periodically, and feed the resulting manifest
    to a --pre-skip-existing download run to fetch only what's new.

    duplicate identifiers (e.g. the same playlist passed via both
    --playlist and --playlists-file) are deduped before fetching, so a
    playlist is never re-fetched from the api twice in one run.
    """
    seen = set()
    deduped = []
    for identifier in playlist_identifiers:
        if identifier not in seen:
            seen.add(identifier)
            deduped.append(identifier)

    print(f"exporting {len(deduped)} playlist(s)...")
    all_tracks = []
    for identifier in deduped:
        all_tracks.extend(export_specific_playlist(sp, identifier, export_dir))

    # merge_and_deduplicate expects (playlist-sourced tracks, liked-songs
    # tracks) - there's no liked-songs side here, just multiple playlists,
    # so pass an empty second list. gives the same id-dedup + fuzzy
    # remaster/regional-version collapse as the full export.
    manifest_tracks = merge_and_deduplicate(all_tracks, [])
    print(f"created playlists manifest with {len(manifest_tracks)} unique tracks")

    # Create spotify subdirectory for service-specific organization
    spotify_dir = os.path.join(export_dir, 'spotify')
    os.makedirs(spotify_dir, exist_ok=True)

    export_to_csv(manifest_tracks, 'playlists_manifest.csv', spotify_dir)
    export_manifest_as_txt(manifest_tracks, spotify_dir, filename='playlists_manifest_urls.txt')

    return manifest_tracks


def export_all_data(sp, export_dir, my_playlists_only=False, exclude_names=None):
    print("starting full Spotify export...")

    user = sp.current_user()
    print(f"authenticated as: {user.get('display_name', 'Unknown User')} ({user.get('id', 'Unknown ID')})")

    # Create spotify subdirectory for service-specific organization
    spotify_dir = os.path.join(export_dir, 'spotify')
    os.makedirs(spotify_dir, exist_ok=True)

    playlists = get_user_playlists(sp, my_playlists_only=my_playlists_only)
    if my_playlists_only:
        print(f"found {len(playlists)} of your playlists")
    else:
        print(f"found {len(playlists)} playlists")

    export_to_csv(playlists, 'playlists.csv', spotify_dir)

    # Process exclusions if provided
    exclude_tokens = build_exclude_tokens(exclude_names) if exclude_names else []

    all_playlist_tracks = []
    for playlist in playlists:
        if is_playlist_excluded(playlist, exclude_tokens):
            continue  # silently skip excluded playlist
        tracks = get_playlist_tracks(sp, playlist.get('id', ''), playlist.get('name', 'Unknown'))
        all_playlist_tracks.extend(tracks)

    export_to_csv(all_playlist_tracks, 'playlist_tracks.csv', spotify_dir)

    liked_songs = get_liked_songs(sp)
    print(f"found {len(liked_songs)} liked songs")
    export_to_csv(liked_songs, 'liked_songs.csv', spotify_dir)

    manifest_tracks = merge_and_deduplicate(all_playlist_tracks, liked_songs)
    print(f"created manifest with {len(manifest_tracks)} unique tracks")

    export_to_csv(manifest_tracks, 'spotify_manifest.csv', spotify_dir)

    export_manifest_as_txt(manifest_tracks, spotify_dir)

    print("\nexport complete! files saved in:", spotify_dir)
    print("- playlists.csv: playlist metadata")
    print("- playlist_tracks.csv: all tracks from non-excluded playlists (with duplicates)")
    print("- liked_songs.csv: all liked/saved tracks")
    print("- spotify_manifest.csv: deduplicated master manifest")
    print("- spotify_manifest_urls.txt: spotify urls for spotdl input")

    return manifest_tracks
