"""playlists.build - build/maintain local .m3u8 files from spotify playlists.

for each spotify playlist (default: only the ones you own), resolve every track
to a file in the crate and write one .m3u8 (relative paths, with a #SPOTIFY:<id>
comment per entry) into PLAYLISTS_PATH. unresolved tracks are logged to the
exports dir as a handoff for the existing `spotify` downloader.

re-running is the add/remove/update semantic: the .m3u8 is rebuilt from current
spotify membership, so adds/removes/reorders on spotify flow through on the next
run. songs may be in multiple playlists.

cli.py owns argument parsing / exit codes; build_playlists() below is the
plain, import-safe entry point - no argparse/sys.exit in here, so core/ can
call it directly later without shelling out.

usage (via playlists' cli):
  uv run playlists --playlist "_obs"                 # preview one (no files written)
  uv run playlists --apply --playlist "_obs"         # write it
  uv run playlists --apply --rescrape --playlist "_obs"  # rescrape just _obs, then build it
  uv run playlists --apply                            # build all your own playlists
  uv run playlists --apply --all                     # include followed/shared lists
  uv run playlists --apply --rescrape --covers        # refresh from spotify + art
  uv run playlists --reindex                          # rebuild the local index sidecar

lib/ refactor: indexer/matcher/m3u now come from lib.catalog.indexer,
lib.catalog.matcher, lib.m3u instead of the (now-deleted) playlists.indexer/
playlists.matcher/playlists.m3u; root resolution comes from lib.paths
instead of playlists.indexer's own resolvers. download.spotify_utils /
download.spotify_to_csv are gone post-Phase-3 - auth is
lib.spotify_auth.authenticate_user(), and get_playlist_tracks/
export_all_data/extract_playlist_id_from_url now live in
download.spotify_api / download.spotify_export respectively.
"""

import csv
import os
import sys

from lib.spotify_auth import authenticate_user
from lib import config
from lib.exclusion import extract_playlist_id_from_url, apply_exclude_filter
from download.spotify.spotify_api import get_playlist_tracks
from download.spotify.spotify_export import export_all_data

from lib.paths import (
    archive_path as resolve_archive_path,
    playlists_path as resolve_playlists_path,
    exports_dir as resolve_exports_dir,
)
from lib.catalog.indexer import get_index
from lib.catalog.match_index import MatchIndex, match_rows
from lib.catalog.links import load_links_safe, links_path
from lib.m3u import safe_name, write_m3u8, read_entries, read_source

try:
    sys.stdout.reconfigure(encoding="utf-8")  # non-ascii artist names on windows
except Exception:
    pass


PLAYLIST_TRACKS_FIELDS = (
    "playlist_id",
    "playlist_name",
    "track_id",
    "track_name",
    "artist_names",
    "album_name",
    "duration_ms",
    "explicit",
    "popularity",
    "added_at",
    "added_by",
    "spotify_url",
    "track_number",
    "disc_number",
    "is_local",
)

PLAYLIST_META_FIELDS = (
    "id",
    "name",
    "description",
    "owner",
    "owner_id",
    "public",
    "track_count",
    "playlist_url",
    "snapshot_id",
)


def _read_csv(path):
    """read a csv into a list of dicts, or [] if missing."""
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def _write_csv(path, rows, fields):
    """atomic, non-fatal csv write. mirrors _write_unmatched: a locked target
    (editor/scanner holding it) warns rather than aborting the build."""
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
        os.replace(tmp, path)
    except OSError as e:
        print(f"  warning: could not write {path}: {e}")


def _group_tracks_by_playlist(rows):
    """playlist_tracks.csv long form -> {playlist_id: [rows...]} preserving csv order
    (which is spotify's playlist order)."""
    groups = {}
    order = []
    for r in rows:
        pid = r.get("playlist_id")
        if not pid:
            continue
        if pid not in groups:
            groups[pid] = []
            order.append(pid)
        groups[pid].append(r)
    return groups


def _select_playlists(playlists_csv, names, all_playlists, exclude_names=None, service="spotify"):
    """apply scope (names over all_playlists over the 'mine' default) ->
    [(meta_row), ...], then filter out any playlist whose name or id
    matches an exclude_names token.

    mostly unchanged from the pre-lib/ version - takes the two scope values
    directly instead of an argparse Namespace.

    the default "mine" scope filters on 'owner_id' (a real Spotify user
    id, same shape as SPOTIFY_USER_ID), not 'owner' (a display name) -
    see PLAYLIST_META_FIELDS and _scope_rescrape()'s meta dict below for
    where that column gets populated. Older exports written before
    'owner_id' existed won't have it; those rows just won't match the
    default scope until re-exported (same as any other never-null'd new
    column - not attempting to backfill it here, since we'd need to
    re-hit Spotify's API to learn each row's real owner id anyway).

    For soundcloud service, the 'mine' filter is disabled since SoundCloud
    doesn't use Spotify user IDs."""
    # Read and validate playlists CSV
    rows = _read_and_validate_playlists_csv(playlists_csv)

    # Apply scope resolution
    if names:
        selected = _handle_names_scope(rows, names)
    elif all_playlists:
        selected = _handle_all_playlists_scope(rows)
    else:
        selected = _handle_default_scope(rows, service)

    # Apply exclude filter
    selected = _apply_exclude_filter(selected, exclude_names)

    return selected


def _read_and_validate_playlists_csv(playlists_csv):
    """Read and validate the playlists CSV file.

    Args:
        playlists_csv: Path to the playlists CSV file

    Returns:
        List of dictionaries representing the CSV rows

    Raises:
        ValueError: If the playlists CSV file is not found or empty
    """
    rows = _read_csv(playlists_csv)
    if not rows:
        raise ValueError(f"no playlists.csv found at {playlists_csv} - run `export` or --rescrape first")
    return rows


def _handle_names_scope(rows, names):
    """Handle scope resolution when specific playlist names/IDs are provided.

    Args:
        rows: List of playlist dictionaries from CSV
        names: List of playlist names or IDs to select

    Returns:
        List of selected playlist dictionaries
    """
    wanted = []
    for token in names:
        as_id = extract_playlist_id_from_url(token)
        is_id = len(as_id) >= 16  # bare id, or id extracted from a url
        wanted.append((token, as_id, is_id))

    selected = []
    for meta in rows:
        for token, as_id, is_id in wanted:
            if is_id and meta.get("id") == as_id:
                selected.append(meta)
                break
            if not is_id and (meta.get("name") == token or meta.get("id") == token or meta.get("playlist_url") == token):
                selected.append(meta)
                break
    return selected


def _handle_all_playlists_scope(rows):
    """Handle scope resolution when all playlists are requested.

    Args:
        rows: List of playlist dictionaries from CSV

    Returns:
        List of all playlist dictionaries (unchanged)
    """
    return rows


def _handle_default_scope(rows, service):
    """Handle scope resolution for the default case (mine vs all).

    Args:
        rows: List of playlist dictionaries from CSV
        service: Service type ('spotify' or 'soundcloud')

    Returns:
        List of filtered playlist dictionaries based on service and user ID
    """
    # default: only your own playlists (for spotify) or all (for soundcloud)
    if service == "soundcloud":
        # For SoundCloud, we don't have Spotify user IDs, so show all playlists
        return rows
    else:
        # default: only your own playlists
        user_id = config.SPOTIFY_USER_ID
        if not user_id:
            print("warning: SPOTIFY_USER_ID not set - can't filter to your playlists; building all.")
            return rows
        else:
            return [r for r in rows if (r.get("owner_id") or "") == user_id]


def _apply_exclude_filter(selected, exclude_names):
    """Apply exclude filter to remove specified playlists from selection.

    Args:
        selected: List of selected playlist dictionaries
        exclude_names: List of playlist names or IDs to exclude

    Returns:
        List of playlist dictionaries with exclusions applied
    """
    filtered, _ = apply_exclude_filter(selected, exclude_names, match_url=True)
    return filtered


def _read_existing_index(archive_path, exports_dir, reindex, verbose):
    library = resolve_archive_path(archive_path)
    if not os.path.isdir(library):
        raise ValueError(f"library root not found: {library} (ARCHIVE_PATH / --archive-path)")
    return get_index(library, exports_dir, reindex=reindex, verbose=verbose)


def _download_cover(sp, playlist_id, dest_path):
    import requests

    try:
        data = sp.playlist(playlist_id, fields="images")
    except Exception as e:
        print(f"  warning: could not fetch cover for {playlist_id}: {e}")
        return False
    images = data.get("images") or []
    url = None
    if images:
        url = max(images, key=lambda im: im.get("width") or 0).get("url")
    if not url:
        return False
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    tmp = dest_path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(resp.content)
    os.replace(tmp, dest_path)
    return True


def _spotify_exports_dir(exports_dir):
    """spotify's csvs live in <exports>/spotify/ (export_* writes them there, same as
    soundcloud's <exports>/soundcloud/). falls back to the old flat <exports>/ layout
    only when that's where a playlists.csv actually is and the new one isn't."""
    new = os.path.join(exports_dir, "spotify")
    if os.path.isfile(os.path.join(new, "playlists.csv")):
        return new
    if os.path.isfile(os.path.join(exports_dir, "playlists.csv")):
        return exports_dir
    return new


def _scope_rescrape(sp, names, exports_dir):
    """--rescrape with -p: fetch only the named playlist(s) from spotify and
    patch their rows into playlists.csv + playlist_tracks.csv, instead of the
    full export_all_data walk of every owned playlist. a name token resolves to
    an id via the existing playlists.csv (one we don't already know can't be
    scraped by name - pass its url or id, or run a full --rescrape first to
    learn it); a url or bare id fetches directly."""
    exports_dir = _spotify_exports_dir(exports_dir)
    os.makedirs(exports_dir, exist_ok=True)
    playlists_csv = os.path.join(exports_dir, "playlists.csv")
    tracks_csv = os.path.join(exports_dir, "playlist_tracks.csv")
    metas = _read_csv(playlists_csv)  # [] on a first run
    tracks = _read_csv(tracks_csv)
    name_to_id = {m.get("name"): m.get("id") for m in metas if m.get("name") and m.get("id")}

    to_fetch, missing = [], []
    for token in names:
        as_id = extract_playlist_id_from_url(token)
        if len(as_id) >= 16:  # bare id, or id extracted from a url
            to_fetch.append((token, as_id))
        elif token in name_to_id:  # a name we already know
            to_fetch.append((token, name_to_id[token]))
        else:
            missing.append(token)

    if missing:
        print(f"warning: can't rescrape by name (not in playlists.csv): {', '.join(missing)}")
        print("         pass its url or id instead, or run a full --rescrape first to learn it.")
    if not to_fetch:
        return

    print(f"rescraping {len(to_fetch)} playlist(s) (--rescrape -p) into {exports_dir}")
    fetch_ids = {pid for _, pid in to_fetch}
    out_tracks = [r for r in tracks if r.get("playlist_id") not in fetch_ids]

    for token, pid in to_fetch:
        try:
            pl = sp.playlist(pid)
        except Exception as e:
            print(f"  warning: could not fetch playlist {token}: {e}")
            continue
        name = pl.get("name") or token
        meta = {
            "id": pl.get("id", ""),
            "name": name,
            "description": pl.get("description", "") or "",
            "owner": (pl.get("owner") or {}).get("display_name", "") or "",
            "owner_id": (pl.get("owner") or {}).get("id", "") or "",
            "public": pl.get("public", False),
            "track_count": (pl.get("tracks") or {}).get("total", 0),
            "playlist_url": (pl.get("external_urls") or {}).get("spotify", ""),
            "snapshot_id": pl.get("snapshot_id", ""),
        }
        # replace in place to keep playlists.csv row order; else append
        for i, m in enumerate(metas):
            if m.get("id") == pid:
                metas[i] = meta
                break
        else:
            metas.append(meta)

        new_tracks = get_playlist_tracks(sp, pid, name)
        print(f"  - {name}: {len(new_tracks)} tracks")
        out_tracks.extend(new_tracks)

    _write_csv(playlists_csv, metas, PLAYLIST_META_FIELDS)
    _write_csv(tracks_csv, out_tracks, PLAYLIST_TRACKS_FIELDS)


def build_playlists(
    apply=False,
    all_playlists=False,
    names=None,
    exclude_names=None,
    rescrape=False,
    covers=False,
    reindex=False,
    verbose=False,
    playlists_path=None,
    archive_path=None,
    exports_dir=None,
    service="spotify",
    cookies_from_browser=None,
    cookie_file=None,
    keep_local=True,
):
    """build/refresh local .m3u8s from current playlist membership (spotify or soundcloud).

    plain, import-safe entry point - cli.py resolves click options into
    these kwargs and turns exceptions into exit codes; nothing in here
    calls sys.exit(), so core/ can call this directly later. `mine` isn't
    a parameter here on purpose: it was always a no-op in the original too
    (argparse only used it for the --all/--mine mutual-exclusion error,
    never inspected past that) - that check now lives in cli.py.

    `exclude_names` filters out playlists after scope resolution but
    before matching: an excluded playlist never generates unmatched rows
    or triggers a cover download. Same id/name resolution as `names`.

    `keep_local=True` (default): when rewriting a synced playlist, re-insert
    its `#TAPEDECK-LOCAL` entries after their previous neighbour instead of
    dropping them.

    Returns a summary dict: {'written', 'skipped', 'unmatched', 'playlists': [...]}
    """
    playlists_path_resolved, exports_dir_resolved = _handle_basic_setup(names, playlists_path, exports_dir)

    # SoundCloud doesn't use the Spotify API - skip auth, but still rescrape
    if service == "soundcloud":
        sp = None
        if rescrape:
            if names:
                from download.soundcloud.soundcloud_export import export_sets as sc_export_sets

                print(f"rescraping {len(names)} soundcloud set(s) (--playlist) into {exports_dir_resolved}")
                sc_export_sets(
                    None,
                    names,
                    exports_dir_resolved,
                    cookies_from_browser=cookies_from_browser,
                    cookie_file=cookie_file,
                )
            elif config.SOUNDCLOUD_PLAYLISTS_FILE:
                from download.soundcloud.soundcloud_export import export_sets as sc_export_sets

                playlists_file = config.SOUNDCLOUD_PLAYLISTS_FILE
                identifiers = []
                with open(playlists_file, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            identifiers.append(line)
                if not identifiers:
                    print(f"warning: SOUNDCLOUD_PLAYLISTS_FILE is set but contains no set urls: {playlists_file}")
                else:
                    print(f"rescraping {len(identifiers)} soundcloud set(s) from {playlists_file} into {exports_dir_resolved}")
                    sc_export_sets(
                        None,
                        identifiers,
                        exports_dir_resolved,
                        cookies_from_browser=cookies_from_browser,
                        cookie_file=cookie_file,
                    )
            else:
                from download.soundcloud.soundcloud_export import export_all_data as sc_export_all_data

                username = config.SOUNDCLOUD_USER
                print(f"rescraping soundcloud (--rescrape) into {exports_dir_resolved}")
                sc_export_all_data(
                    None,
                    username,
                    exports_dir_resolved,
                    cookies_from_browser=cookies_from_browser,
                    cookie_file=cookie_file,
                )
    else:
        sp = _handle_authentication(rescrape, covers)
        _handle_rescrape(sp, names, exports_dir_resolved, exclude_names, rescrape)

    playlists_csv, tracks_csv, service_exports_dir = _determine_file_paths(service, exports_dir_resolved)
    selected, grouped = _select_and_group_playlists(playlists_csv, tracks_csv, names, all_playlists, exclude_names, service)

    _print_build_info(selected, tracks_csv, verbose, service)

    index, mindex = _setup_index_and_matcher(archive_path, exports_dir_resolved, reindex, verbose)

    total_tracks, total_matched, total_unmatched, total_written, unmatched_rows = _initialize_counters()

    # Service-specific cover downloader (Spotify: uses the Spotify API).
    cover_downloader = None
    if covers and sp is not None:

        def _spotify_cover_downloader(pid, dest_path):
            return _download_cover(sp, pid, dest_path)

        cover_downloader = _spotify_cover_downloader

    total_tracks, total_matched, total_unmatched, total_written, unmatched_rows = _process_playlists(
        selected,
        grouped,
        index,
        mindex,
        apply,
        playlists_path_resolved,
        service_exports_dir,
        cover_downloader=cover_downloader,
        url_field="spotify_url",
        service=service,
        total_tracks=total_tracks,
        total_matched=total_matched,
        total_unmatched=total_unmatched,
        total_written=total_written,
        unmatched_rows=unmatched_rows,
        verbose=verbose,
        keep_local=keep_local,
    )

    _finalize_and_report(
        service_exports_dir,
        unmatched_rows,
        total_written,
        selected,
        total_matched,
        total_unmatched,
        total_tracks,
        url_field="spotify_url",
    )

    return {
        "written": total_written,
        "skipped": len(selected) - total_written,
        "unmatched": total_unmatched,
        "playlists": [{"id": m.get("id"), "name": m.get("name")} for m in selected],
    }


def _handle_basic_setup(names, playlists_path, exports_dir):
    """Handle basic setup: parameter validation and directory creation."""
    names = names or []
    playlists_path_resolved = resolve_playlists_path(playlists_path)
    exports_dir_resolved = resolve_exports_dir(playlists_path_resolved, exports_dir)
    os.makedirs(playlists_path_resolved, exist_ok=True)
    return playlists_path_resolved, exports_dir_resolved


def _handle_authentication(rescrape, covers):
    """Handle authentication setup if needed."""
    sp = None
    if rescrape or covers:
        sp = authenticate_user()
    return sp


def _handle_rescrape(sp, names, exports_dir_resolved, exclude_names, rescrape):
    """Handle rescrape functionality."""
    if rescrape:
        if names:
            _scope_rescrape(sp, names, exports_dir_resolved)
        else:
            print("rescraping spotify (--rescrape) into " + exports_dir_resolved)
            export_all_data(sp, exports_dir_resolved, my_playlists_only=True, exclude_names=exclude_names)


def _determine_file_paths(service, exports_dir_resolved):
    """Determize file paths based on service type."""
    if service == "soundcloud":
        playlists_csv = os.path.join(exports_dir_resolved, "soundcloud", "playlists.csv")
        tracks_csv = os.path.join(exports_dir_resolved, "soundcloud", "playlist_tracks.csv")
        service_exports_dir = os.path.join(exports_dir_resolved, "soundcloud")
    else:  # spotify (default)
        service_exports_dir = _spotify_exports_dir(exports_dir_resolved)
        playlists_csv = os.path.join(service_exports_dir, "playlists.csv")
        tracks_csv = os.path.join(service_exports_dir, "playlist_tracks.csv")
    return playlists_csv, tracks_csv, service_exports_dir


def _select_and_group_playlists(playlists_csv, tracks_csv, names, all_playlists, exclude_names, service):
    """Select and group playlists based on parameters."""
    selected = _select_playlists(playlists_csv, names, all_playlists, exclude_names=exclude_names, service=service)
    grouped = _group_tracks_by_playlist(_read_csv(tracks_csv))
    return selected, grouped


def _print_build_info(selected, tracks_csv, verbose, service="spotify"):
    """Print build information if verbose or few playlists."""
    print(f"\nbuilding {len(selected)} playlist(s) from {tracks_csv}")
    if len(selected) <= 12 or verbose:
        for m in selected:
            print(f"  - {m.get('name')} ({m.get('track_count')} tracks on {service})")


def _setup_index_and_matcher(archive_path, exports_dir_resolved, reindex, verbose):
    """Setup index and matcher for playlist processing."""
    index = _read_existing_index(archive_path, exports_dir_resolved, reindex, verbose)
    # manual links live beside the index sidecar, so honor the same
    # exports_dir override; paths resolve against the same crate root.
    mindex = MatchIndex(
        index,
        links=load_links_safe(links_path(exports_dir_resolved)),
        library_root=resolve_archive_path(archive_path),
    )
    return index, mindex


def _initialize_counters():
    """Initialize counters for the processing loop."""
    total_tracks = total_matched = total_unmatched = total_written = 0
    unmatched_rows = []
    return total_tracks, total_matched, total_unmatched, total_written, unmatched_rows


def plan_playlist(meta, rows, mindex, verbose=False):
    """Pure: match ``rows`` against the catalog and return the entries a
    ``.m3u8`` would hold for this playlist, plus the unmatched rows.

    No files are written - used by both ``build_playlists`` and the app's
    preview/diff endpoints.  Each matched entry carries ``track_id``,
    ``artist``, ``title``, ``length``, ``path`` (absolute) and ``tier``.
    """
    results = match_rows(rows, index=mindex, verbose=verbose)
    entries = []
    unmatched = []
    for rec in results:
        row = rec["row"]
        if rec["path"]:
            entries.append(
                {
                    "track_id": row.get("track_id", ""),
                    "artist": row.get("artist_names", ""),
                    "title": row.get("track_name", ""),
                    "length": rec["length"],
                    "path": rec["path"],
                    "tier": rec["tier"],
                }
            )
        else:
            unmatched.append(
                {
                    "playlist_name": meta.get("name", ""),
                    "track_id": row.get("track_id", ""),
                    "track_name": row.get("track_name", ""),
                    "artist_names": row.get("artist_names", ""),
                    "album_name": row.get("album_name", ""),
                    "tier_tried": rec["tier"],
                }
            )
    return entries, unmatched


def _merge_keep_local(new_entries, old_entries):
    """re-insert old ``#TAPEDECK-LOCAL`` entries after their previous
    non-local neighbour (anchor) in the new synced list; anchor gone ->
    append at end.  Matches on absolute path."""
    new_by_path = {}
    for e in new_entries:
        p = e.get("path")
        if p:
            new_by_path[os.path.normpath(p)] = e

    insert_after = {}  # anchor_path -> [local entries] ; None -> unanchored
    for i, old in enumerate(old_entries):
        if not old.get("local"):
            continue
        anchor = None
        for j in range(i - 1, -1, -1):
            if not old_entries[j].get("local"):
                anchor = old_entries[j]
                break
        anchor_path = os.path.normpath(anchor["path"]) if anchor and anchor.get("path") else None
        local_entry = {
            "track_id": old.get("track_id", ""),
            "artist": old.get("artist", ""),
            "title": old.get("title", ""),
            "length": old.get("length", 0),
            "path": old.get("path"),
            "rel": old.get("rel", ""),
            "local": True,
            "extinf": old.get("extinf"),
        }
        insert_after.setdefault(anchor_path, []).append(local_entry)

    result = []
    for e in new_entries:
        result.append(e)
        p = os.path.normpath(e.get("path", "")) if e.get("path") else None
        for local_e in insert_after.pop(p, []):
            result.append(local_e)
    for local_e in insert_after.pop(None, []):
        result.append(local_e)
    # any anchors that were never reached (shouldn't happen) - append their locals
    for anchor_path, locals_ in insert_after.items():
        result.extend(locals_)
    return result


def _process_playlists(
    selected,
    grouped,
    index,
    mindex,
    apply,
    playlists_path,
    exports_dir,
    cover_downloader=None,
    url_field="spotify_url",
    service="spotify",
    total_tracks=0,
    total_matched=0,
    total_unmatched=0,
    total_written=0,
    unmatched_rows=None,
    verbose=False,
    keep_local=True,
):
    """Process each playlist in the selection: match tracks against the catalog,
    write .m3u8 files for matched playlists, collect unmatched rows.

    `cover_downloader` is an optional callable(pid, dest_path) -> bool; when
    provided and a playlist is written, it's called to fetch cover art.
    `url_field` names the key in each track row that holds the service-specific
    URL (e.g. 'spotify_url') - it's stored in unmatched rows for the handoff.
    `service` is used for the #TAPEDECK-SOURCE header stamp.
    This section is source-agnostic: it knows nothing about Spotify vs
    SoundCloud auth, rescrape, or cover download - those live in the caller.
    """
    if unmatched_rows is None:
        unmatched_rows = []

    row_by_tid = {}
    for meta in selected:
        for row in grouped.get(meta.get("id"), []):
            row_by_tid[row.get("track_id", "")] = row

    for i, meta in enumerate(selected, 1):
        pid = meta.get("id")
        name = meta.get("name") or meta.get("id") or "Unknown"
        rows = grouped.get(pid, [])
        entries, pl_unmatched = plan_playlist(meta, rows, mindex, verbose=verbose)

        matched_entries = entries
        total_tracks += len(rows)
        total_matched += len(matched_entries)
        total_unmatched += len(pl_unmatched)
        for u in pl_unmatched:
            u[url_field] = row_by_tid.get(u["track_id"], {}).get(url_field, "")
        unmatched_rows.extend(pl_unmatched)

        unmatched_count = len(rows) - len(matched_entries)
        print(f"\n[{i}/{len(selected)}] {name} - {len(matched_entries)}/{len(rows)} matched ({unmatched_count} unmatched)")

        if apply and matched_entries:
            expected_source = f"{service}:{pid}"
            m3u8_path = os.path.join(playlists_path, safe_name(name) + ".m3u8")

            # --- guard: don't clobber a local playlist; collision-proof on name clash ---
            existing_source = read_source(m3u8_path) if os.path.exists(m3u8_path) else ""
            if existing_source == "local":
                print(f"  skip {m3u8_path} (local playlist, not overwritten by sync)")
                continue
            if existing_source and existing_source != expected_source:
                m3u8_path = os.path.join(playlists_path, f"{safe_name(name)} ({pid[:6]}).m3u8")
                print(f"  name collision -> {m3u8_path}")

            # keep_local: re-insert old #TAPEDECK-LOCAL entries after their neighbour
            if keep_local and os.path.exists(m3u8_path) and existing_source in ("", expected_source):
                old_entries, _, _ = read_entries(m3u8_path)
                matched_entries = _merge_keep_local(matched_entries, old_entries)

            write_m3u8(m3u8_path, matched_entries, source=expected_source)
            total_written += 1
            print(f"  wrote {m3u8_path}")
            if cover_downloader:
                cover = os.path.join(playlists_path, safe_name(name) + ".jpg")
                got = cover_downloader(pid, cover)
                if got:
                    print(f"  wrote {cover}")

    return total_tracks, total_matched, total_unmatched, total_written, unmatched_rows


def _finalize_and_report(
    service_exports_dir,
    unmatched_rows,
    total_written,
    selected,
    total_matched,
    total_unmatched,
    total_tracks,
    url_field="spotify_url",
):
    """Finalize processing and print final report."""
    # Ensure service-specific exports directory exists
    os.makedirs(service_exports_dir, exist_ok=True)
    _write_unmatched(service_exports_dir, unmatched_rows, url_field=url_field)

    print(
        f"\ndone. {total_written}/{len(selected)} playlists written "
        f"({total_matched} matched / {total_unmatched} unmatched of {total_tracks} tracks)"
    )
    print(
        f"unmatched -> {os.path.join(service_exports_dir, 'unmatched.csv')}, "
        f"{os.path.join(service_exports_dir, 'unmatched_urls.txt')}"
    )


def _write_unmatched(exports_dir, rows, url_field="spotify_url"):
    """atomic, non-fatal: the handoff is a convenience sidecar, so a locked target
    (file open in an editor, a scanner holding it) should warn, not abort the build."""
    csv_path = os.path.join(exports_dir, "unmatched.csv")
    txt_path = os.path.join(exports_dir, "unmatched_urls.txt")
    fields = ("playlist_name", "track_id", "track_name", "artist_names", "album_name", "tier_tried", url_field)
    urls = []
    seen = set()
    body_lines = []
    body_lines.append(",".join(fields))
    for r in rows:
        body_lines.append(",".join(_csv_escape(r.get(k, "")) for k in fields))
        u = (r.get(url_field) or "").strip()
        if u and u not in seen:
            seen.add(u)
            urls.append(u)
    for path, text in ((csv_path, "\n".join(body_lines) + "\n"), (txt_path, "\n".join(urls) + ("\n" if urls else ""))):
        try:
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8-sig", newline="") as f:
                f.write(text)
            os.replace(tmp, path)
        except OSError as e:
            print(f"  warning: could not write {path}: {e}")
    return len(rows)


def _csv_escape(v):
    v = str(v)
    if "," in v or '"' in v or "\n" in v:
        v = '"' + v.replace('"', '""') + '"'
    return v
